package me.vlcik128.TNT;

import org.bukkit.ChatColor;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
   public static String prefix;

   static {
      prefix = ChatColor.DARK_RED + "[" + ChatColor.RED + "T" + ChatColor.WHITE + "N" + ChatColor.RED + "T" + ChatColor.DARK_RED + "] ";
   }

   public void onEnable() {
      this.getLogger().info("Plugin is enabled.");
      PluginManager pm = this.getServer().getPluginManager();
      pm.registerEvents(new Events(), this);
   }
}
