package me.vlcik128.TNT;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class Events implements Listener {
   @EventHandler
   public void onPlace(BlockPlaceEvent e) {
      Block b = e.getBlock();
      Player p = e.getPlayer();
      if (b != null && b.getType() != Material.AIR && p != null) {
         if (b.getType() == Material.TNT) {
            Bukkit.broadcastMessage(Main.prefix + ChatColor.GOLD + "Player " + ChatColor.AQUA + p.getName().toString().toLowerCase() + ChatColor.GOLD + " placed the " + ChatColor.RED + "TNT " + ChatColor.GOLD + "block!");
         }

      }
   }

   @EventHandler
   public void onClick(PlayerInteractEvent e) {
      Player p = e.getPlayer();
      Block b = e.getClickedBlock();
      Action a = e.getAction();
      ItemStack is = e.getItem();
      if (p != null) {
         if (b != null && b.getType() == Material.TNT) {
            if (a != null && a == Action.RIGHT_CLICK_BLOCK) {
               if (is != null && is.getType() == Material.FLINT_AND_STEEL) {
                  if (a == Action.RIGHT_CLICK_BLOCK && is.getType() == Material.FLINT_AND_STEEL && b.getType() == Material.TNT) {
                     Bukkit.broadcastMessage(Main.prefix + ChatColor.GOLD + "Player " + ChatColor.AQUA + p.getName() + ChatColor.GOLD + " activated the TNT!");
                  }

               }
            }
         }
      }
   }
}
